# Pyarmor 8.5.2 (trial), 000000, 2024-06-06T22:18:05.633100
from .pyarmor_runtime import __pyarmor__
