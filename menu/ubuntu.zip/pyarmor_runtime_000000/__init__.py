# Pyarmor 8.5.2 (trial), 000000, 2024-05-23T00:07:14.285731
from .pyarmor_runtime import __pyarmor__
